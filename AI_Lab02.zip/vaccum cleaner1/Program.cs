﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vaccum_cleaner1
{
    class Program{
    

        static void Main(string[] args)
        {

            Random rand = new Random();
            int[,] floor = new int[3,3];

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    floor[i, j] = rand.Next(0, 2);
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(floor[i, j]);
                }
                Console.WriteLine();
            }

            int x = Convert.ToInt32(Console.ReadLine());
            int y = Convert.ToInt32(Console.ReadLine());

            for(int i=x;i<3;i++)
            {
                for(int j=y;j<3;j++)
                {
                    if(floor[i,j]==1)
                    {
                        Console.Write("dirty at ");
                        Console.Write(i);
                        Console.WriteLine(","+j);
                        floor[i,j]=0;
                        Console.Write("cleaned at ");
                        Console.Write(i);
                        Console.WriteLine("," + j);
                    }
                    else
                    {
                        Console.Write("clean at ");
                        
                        Console.Write(i);
                        Console.WriteLine("," + j);
                    }
                }
            }

            for(int i=x;i>=0;i--)
            {
                for(int j=y;j>=0;j--)
                {
                    if(floor[i,j]==1)
                    {
                    Console.Write("dirty at ");
                    Console.Write(i);
                    Console.WriteLine("," + j);
                        floor[i,j]=0;
                        Console.Write("cleaned at ");
                        Console.Write(i);
                        Console.WriteLine("," + j);
                    }
                    else
                    {
                    Console.Write("clean at ");
                    Console.Write(i);
                    
                    Console.WriteLine("," + j);
                    }
                }
            }


            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(floor[i, j]);
                    floor[i, j] = 0;
                }
                Console.WriteLine();
            }


               




            Console.ReadKey();
        }

        
       
    }
}
