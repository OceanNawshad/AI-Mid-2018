﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backtrack
{
    class function
    {
        public bool canColor(int node,int j)
        {
            for (int i = 0; i < 6; i++)
            {
                if (adjacencyGraph[node,i] == 1)
                {
                    if (vcolor[i]==i)
                    { 
                        
                    }
                }
            }
                return true;
        }
        
        public bool allNodeColored(int node)
        {
            int N = 6;
            if (node == N)
            {
                return true;
            }
            else
            { return false; }
            
        }
        public bool colorGraph(int node)
        {
            if (allNodeColored(node))
            {
                return true;
            }
            else
            {
                for (int i = 0; i < 3; i++)
                {
                    if (canColor(node,i))
                    {
                        vcolor[node] = color[i];
                        if (colorGraph(node + 1))
                        {
                            return true;
                        }
                        vcolor[node] = 0;
                    }
                }
                return false;
            }

            
        }
            int[,] adjacencyGraph = new int[,] { {0,1,1,0,0,0}, {1,0,1,1,0,0}, {1,1,0,1,1,1}, {0,1,1,0,1,0},{0,0,1,1,0,1},{0,0,1,0,1,0} };
            int[] color = new int[3] { 0, 1, 2 };
            int[] vcolor = new int[6];

            int node=0;

            function f1 = new function();
            
           
           

              
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.ReadKey();
        }

    }
}
