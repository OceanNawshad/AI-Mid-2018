﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vaccum_cleaner1
{
    class Program
    {

        public void reflexVaccum(int[]array)
        { 
           
            

            if (array[0] == 1)
            {
                Console.WriteLine("cleaning");
                array[0]=0;
                Console.WriteLine("right");
            }

            else if (array[1] == 1)
            {
                Console.WriteLine("cleaning");
                array[1] = 0;
                Console.WriteLine("left");
            }

            if (array[0] == 0)
            {
                
                
                Console.WriteLine("right");
            }

            if (array[1] == 0)
            {
                Console.WriteLine("left");
            }
        }


        static void Main(string[] args)
        {
            int []array=new int[2];
            Random r=new Random();
            for (int i = 0; i < 2; i++)
            {
                array[i] = r.Next(0, 2);
            }
            Random rand = new Random();
            Console.WriteLine("please enter either 0 or 1");
            int x = Convert.ToInt32(Console.ReadLine());
            


            Program p1 = new Program();

            p1.reflexVaccum(array);

            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine(array[i]);
            }










                Console.ReadKey();
        }



    }
}
