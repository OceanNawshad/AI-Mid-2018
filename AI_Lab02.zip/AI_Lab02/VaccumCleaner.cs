﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI_Lab02
{
    class VaccumCleaner
    {
        enum State { Clean = 0, Dirty = 1 };

        enum Move { Left = 0, Right = 1 };

        int[,] floor;

        public VaccumCleaner(int[,] floor)
        {
            this.floor = floor;
        }

        public void SelectTile(int rowVal, int colVal)
        {
            if ((State)floor[rowVal, colVal] == State.Clean)
            {
                Console.WriteLine("Tile is clean.");
                NextMove(rowVal, colVal);
            }
            else if ((State)floor[rowVal, colVal] == State.Dirty)
            {
                Console.WriteLine("Dirt Found. The tile got sucked and cleaned!");
                floor[rowVal, colVal] = (int)State.Clean;
                NextMove(rowVal, colVal);
            }
        }

        public void NextMove(int rowVal, int colVal)
        {
            if (colVal == 0 && colVal == floor.GetUpperBound(0))
            {
                Console.WriteLine("Can't Move!");
            }
            else if (colVal == 0)
            {
                Console.WriteLine("Next Move: " + Move.Right);
            }
            else if (colVal == floor.GetUpperBound(1))
            {
                Console.WriteLine("Next Move: " + Move.Left);
            }
            else
            {
                Console.WriteLine("Next Move left/right.");
            }
        }

        public void CleanTheFloor()
        {
            int rowVal = 0, colVal = 0;
            Move nextMove = Move.Right;

            for (int i = 0; i < (floor.GetLength(0) * floor.GetLength(1)); i++)
            {
                if ((State)floor[rowVal, colVal] == State.Clean)
                {
                    Console.WriteLine("Tile is clean.");
                }
                else if ((State)floor[rowVal, colVal] == State.Dirty)
                {
                    Console.WriteLine("Dirt Found. The tile got sucked and cleaned!");
                    floor[rowVal, colVal] = (int)State.Clean;
                }

                if (nextMove == Move.Right && colVal != floor.GetUpperBound(1))
                {
                    colVal++;
                    Console.WriteLine("Moving Right");
                }

                else if (nextMove == Move.Right && colVal == floor.GetUpperBound(1))
                {
                    nextMove = Move.Left;
                    rowVal++;
                    Console.WriteLine("Moving Down");
                }

                else if (nextMove == Move.Left && colVal != floor.GetLowerBound(1))
                {
                    colVal--;
                    Console.WriteLine("Moving Left");
                }

                else if (nextMove == Move.Left && colVal == floor.GetLowerBound(1))
                {
                    nextMove = Move.Right;
                    rowVal++;
                    Console.WriteLine("Moving Down");
                }

            }
        }

        public void ShowFloor()
        {
            for (int i = 0; i < floor.GetLength(0); i++)
            {
                for (int x = 0; x < floor.GetLength(1); x++)
                {
                    Console.Write(floor.GetValue(i, x) + "  ");
                }
                Console.WriteLine();
            }
        }

    }
}
