﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI_Lab02
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int[,] floor = new int[,]
            {
                {0, 1, 1},
                {1, 0, 1},
                {0, 1, 1},
                {0, 0, 1},
            };

            VaccumCleaner vc = new VaccumCleaner(floor);

            vc.ShowFloor();

            vc.CleanTheFloor();

            vc.ShowFloor();

            /*
             vc.SelectTile(2, 0);

            vc.ShowFloor();

            vc.SelectTile(2, 1);

            vc.ShowFloor();

            vc.SelectTile(2, 2);

            vc.ShowFloor();
             
             */

            Console.ReadKey();
        }
    }
}
